# Stardew Companion — projeto Android nativo

Aplicativo Android independente feito em Kotlin + Jetpack Compose. A interface não é uma página web e abre como um app instalado, com nome e ícone de inicialização do Android.

## O que já está implementado
- Interface inspirada nos menus de Stardew Valley: verde floresta, painéis de pergaminho e detalhes dourados.
- Navegação por Início, Wiki, Pacotes, Cultivos e Favoritos.
- Catálogo local inicial com cultivos, moradores, peixes, locais, sistemas, coleções e equipamentos.
- Busca e filtros no catálogo.
- Favoritos, checklist de itens dos pacotes e planejamento de cultivos salvos no aparelho.
- Links diretos para os artigos correspondentes da Wiki em português.

## Limite importante desta versão
Este é o primeiro pacote funcional do projeto, não uma cópia integral dos cerca de dois mil artigos da Wiki. O catálogo local já permite consulta e organização offline, mas os artigos completos, detalhes extensos (por exemplo, agendas, presentes favoritos, horários de peixes e tabelas de itens) ainda precisam ser incorporados ao banco interno. Os links para a Wiki abrem o conteúdo completo quando há internet. Não vou apresentar o conteúdo parcial como se fosse uma Wiki totalmente offline.

## Como gerar o APK automaticamente
Incluí o workflow `.github/workflows/build-apk.yml` para compilar o APK na infraestrutura do GitHub:
1. Crie um repositório no GitHub e envie o conteúdo desta pasta para a branch `main`.
2. Abra a aba **Actions** do repositório.
3. Selecione **Build Android APK** e clique em **Run workflow** (ou aguarde a compilação após o primeiro push).
4. Quando terminar, abra a execução e baixe o artefato **Stardew-Companion-debug-apk**. Dentro dele estará `app-debug.apk`.
5. Transfira o APK para o Android e instale. O Android poderá pedir autorização para instalar apps dessa origem.

## Compilação local
Requer Android Studio, Android SDK 35, Java 17 e Gradle 8.9. Abra esta pasta no Android Studio e execute `assembleDebug`.

## Referência de terminologia
Os nomes e os artigos vinculados usam como referência a Wiki em português: https://pt.stardewvalleywiki.com/Stardew_Valley_Wiki

Projeto de fã, independente e não afiliado a ConcernedApe ou à equipe de Stardew Valley. Não inclui sprites, músicas ou outros arquivos extraídos do jogo.
