package com.stardewcompanion.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.style.TextAlign
import android.content.Context

private val Forest = Color(0xFF315B3B)
private val Leaf = Color(0xFF668A4D)
private val Cream = Color(0xFFF3E8C8)
private val Paper = Color(0xFFFFF8E8)
private val Brown = Color(0xFF6C4B2F)
private val Gold = Color(0xFFD7A94B)
private val Ink = Color(0xFF342D22)
private val Muted = Color(0xFF81745E)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StardewApp() }
    }
}

data class WikiEntry(val name: String, val type: String, val description: String, val wikiSlug: String)
data class BundleGroup(val name: String, val items: List<String>)

private val catalog = listOf(
    // Cultivos e coleta
    WikiEntry("Pastinaca", "Cultivo", "Cultivo da Primavera. Cresce a partir de sementes de pastinaca.", "Pastinaca"),
    WikiEntry("Vagem", "Cultivo", "Cultivo da Primavera que continua produzindo após a primeira colheita.", "Vagem"),
    WikiEntry("Couve-flor", "Cultivo", "Cultivo da Primavera. Também pode gerar uma couve-flor gigante.", "Couve-flor"),
    WikiEntry("Batata", "Cultivo", "Cultivo da Primavera.", "Batata"),
    WikiEntry("Morango", "Cultivo", "Cultivo da Primavera vendido no Festival do Ovo.", "Morango"),
    WikiEntry("Couve", "Cultivo", "Cultivo da Primavera.", "Couve"),
    WikiEntry("Ruibarbo", "Cultivo", "Cultivo da Primavera comprado no Oásis.", "Ruibarbo"),
    WikiEntry("Melão", "Cultivo", "Cultivo do Verão. Pode gerar um melão gigante.", "Melão"),
    WikiEntry("Tomate", "Cultivo", "Cultivo do Verão que continua produzindo.", "Tomate"),
    WikiEntry("Mirtilo", "Cultivo", "Cultivo do Verão que produz várias frutas por colheita.", "Mirtilo"),
    WikiEntry("Pimenta quente", "Cultivo", "Cultivo do Verão que continua produzindo.", "Pimenta_quente"),
    WikiEntry("Milho", "Cultivo", "Cultivo de Verão e Outono.", "Milho"),
    WikiEntry("Lúpulo", "Cultivo", "Cultivo do Verão usado em receitas artesanais.", "Lúpulo"),
    WikiEntry("Carambola", "Cultivo", "Cultivo do Verão comprado no Oásis.", "Carambola"),
    WikiEntry("Abóbora", "Cultivo", "Cultivo do Outono. Pode gerar uma abóbora gigante.", "Abóbora"),
    WikiEntry("Oxicoco", "Cultivo", "Cultivo do Outono que continua produzindo.", "Oxicoco"),
    WikiEntry("Berinjela", "Cultivo", "Cultivo do Outono que continua produzindo.", "Berinjela"),
    WikiEntry("Inhame", "Cultivo", "Cultivo do Outono.", "Inhame"),
    WikiEntry("Uva", "Cultivo", "Cultivo do Outono.", "Uva"),
    WikiEntry("Amaranto", "Cultivo", "Cultivo do Outono.", "Amaranto"),
    WikiEntry("Fruta antiga", "Cultivo", "Cultivo raro que pode produzir durante várias estações.", "Fruta_antiga"),
    WikiEntry("Semente rara", "Semente", "Semente especial que pode ser plantada no Outono.", "Semente_rara"),
    // Personagens
    WikiEntry("Abigail", "Morador", "Moradora de Pelicanos. Consulte a página para agenda e preferências.", "Abigail"),
    WikiEntry("Alex", "Morador", "Morador de Pelicanos. Consulte a página para agenda e preferências.", "Alex"),
    WikiEntry("Elliott", "Morador", "Morador de Pelicanos. Consulte a página para agenda e preferências.", "Elliott"),
    WikiEntry("Emily", "Morador", "Moradora de Pelicanos. Consulte a página para agenda e preferências.", "Emily"),
    WikiEntry("Haley", "Morador", "Moradora de Pelicanos. Consulte a página para agenda e preferências.", "Haley"),
    WikiEntry("Harvey", "Morador", "Médico da cidade. Consulte a página para agenda e preferências.", "Harvey"),
    WikiEntry("Leah", "Morador", "Moradora de Pelicanos. Consulte a página para agenda e preferências.", "Leah"),
    WikiEntry("Maru", "Morador", "Moradora de Pelicanos. Consulte a página para agenda e preferências.", "Maru"),
    WikiEntry("Penny", "Morador", "Moradora de Pelicanos. Consulte a página para agenda e preferências.", "Penny"),
    WikiEntry("Sam", "Morador", "Morador de Pelicanos. Consulte a página para agenda e preferências.", "Sam"),
    WikiEntry("Sebastian", "Morador", "Morador de Pelicanos. Consulte a página para agenda e preferências.", "Sebastian"),
    WikiEntry("Shane", "Morador", "Morador de Pelicanos. Consulte a página para agenda e preferências.", "Shane"),
    WikiEntry("Linus", "Morador", "Morador que vive nas montanhas.", "Linus"),
    WikiEntry("Marnie", "Morador", "Administra o rancho de animais.", "Marnie"),
    WikiEntry("Willy", "Morador", "Pescador e dono da loja de pesca.", "Willy"),
    WikiEntry("Caroline", "Morador", "Moradora de Pelicanos.", "Caroline"),
    WikiEntry("Clint", "Morador", "Ferreiro da cidade.", "Clint"),
    WikiEntry("Demetrius", "Morador", "Cientista que vive nas montanhas.", "Demetrius"),
    WikiEntry("Evelyn", "Morador", "Moradora de Pelicanos.", "Evelyn"),
    WikiEntry("George", "Morador", "Morador de Pelicanos.", "George"),
    WikiEntry("Gus", "Morador", "Dono do Saloon Fruta Estelar.", "Gus"),
    WikiEntry("Jas", "Morador", "Moradora de Pelicanos.", "Jas"),
    WikiEntry("Jodi", "Morador", "Moradora de Pelicanos.", "Jodi"),
    WikiEntry("Kent", "Morador", "Morador de Pelicanos.", "Kent"),
    WikiEntry("Leo", "Morador", "Morador da Ilha Gengibre.", "Leo"),
    WikiEntry("Pam", "Morador", "Motorista do ônibus.", "Pam"),
    WikiEntry("Pierre", "Morador", "Dono do armazém.", "Pierre"),
    WikiEntry("Robin", "Morador", "Carpinteira da cidade.", "Robin"),
    WikiEntry("Sandy", "Morador", "Dona da loja do Oásis.", "Sandy"),
    WikiEntry("Vincent", "Morador", "Morador de Pelicanos.", "Vincent"),
    WikiEntry("Willy", "Morador", "Pescador e dono da loja de pesca.", "Willy"),
    // Pesca, locais, sistemas e coleções
    WikiEntry("Peixe-sol", "Peixe", "Peixe de rio. Consulte estação, clima e horário na Wiki.", "Peixe-sol"),
    WikiEntry("Bagre", "Peixe", "Peixe de rio associado à chuva em determinadas estações.", "Bagre"),
    WikiEntry("Sável", "Peixe", "Peixe de rio. Consulte estação e horário na Wiki.", "Sável"),
    WikiEntry("Truta-tigre", "Peixe", "Peixe de rio disponível em estações específicas.", "Truta-tigre"),
    WikiEntry("Achigã", "Peixe", "Peixe de água doce. Consulte os locais de pesca.", "Achigã"),
    WikiEntry("Carpa", "Peixe", "Peixe de água doce encontrado em diferentes locais.", "Carpa"),
    WikiEntry("Esturjão", "Peixe", "Peixe do lago da montanha.", "Esturjão"),
    WikiEntry("Sardinha", "Peixe", "Peixe do oceano.", "Sardinha"),
    WikiEntry("Atum", "Peixe", "Peixe do oceano disponível em estações específicas.", "Atum"),
    WikiEntry("Tilápia", "Peixe", "Peixe do oceano.", "Tilápia"),
    WikiEntry("Centro Comunitário", "Local", "Salas, conjuntos, itens necessários e recompensas.", "Centro_Comunitário"),
    WikiEntry("Museu", "Local", "Coleção de artefatos e minerais.", "Museu"),
    WikiEntry("Minas", "Local", "Andares, recursos, monstros e progressão.", "Minas"),
    WikiEntry("Deserto de Calico", "Local", "Área desbloqueada ao reparar o ônibus.", "Deserto_de_Calico"),
    WikiEntry("Ilha Gengibre", "Local", "Região desbloqueada após reparar o barco.", "Ilha_Gengibre"),
    WikiEntry("Esgotos", "Local", "Área subterrânea com personagens e conteúdos próprios.", "Esgotos"),
    WikiEntry("Lavouras", "Guia", "Lista de cultivos, sementes, estações e colheitas.", "Lavouras"),
    WikiEntry("Aldeões", "Guia", "Moradores, amizade, presentes e agendas.", "Aldeões"),
    WikiEntry("Peixes", "Guia", "Peixes, locais, estações, clima e horários.", "Peixes"),
    WikiEntry("Conjuntos", "Guia", "Todos os conjuntos do Centro Comunitário.", "Conjuntos"),
    WikiEntry("Presentes", "Guia", "Preferências de presentes dos moradores.", "Presentes"),
    WikiEntry("Receitas", "Guia", "Receitas de culinária e fabricação.", "Receitas"),
    WikiEntry("Conquistas", "Guia", "Lista de conquistas e requisitos.", "Conquistas"),
    WikiEntry("Calendário", "Guia", "Aniversários, festivais e eventos do ano.", "Calendário"),
    WikiEntry("Artesanato", "Guia", "Máquinas, itens fabricáveis e materiais.", "Artesanato"),
    WikiEntry("Animais", "Guia", "Animais de fazenda, produtos e cuidados.", "Animais"),
    WikiEntry("Monstros", "Guia", "Criaturas, locais e itens obtidos.", "Monstros"),
    WikiEntry("Artefatos", "Coleção", "Itens doados ao Museu e locais de obtenção.", "Artefatos"),
    WikiEntry("Minerais", "Coleção", "Minerais, geodos e doações ao Museu.", "Minerais"),
    WikiEntry("Ferramentas", "Equipamento", "Ferramentas, melhorias e usos.", "Ferramentas"),
    WikiEntry("Anéis", "Equipamento", "Anéis e efeitos.", "Anéis"),
    WikiEntry("Armas", "Equipamento", "Armas e equipamentos de combate.", "Armas")
)

private val bundleGroups = listOf(
    BundleGroup("Despensa • Cultivos da Primavera", listOf("Pastinaca", "Vagem", "Couve-flor", "Batata")),
    BundleGroup("Despensa • Cultivos do Verão", listOf("Tomate", "Pimenta quente", "Mirtilo", "Melão")),
    BundleGroup("Despensa • Cultivos do Outono", listOf("Milho", "Berinjela", "Abóbora", "Inhame")),
    BundleGroup("Aquário • Peixes de rio", listOf("Peixe-sol", "Bagre", "Sável", "Truta-tigre")),
    BundleGroup("Aquário • Peixes do lago", listOf("Achigã", "Carpa", "Cabeça-de-touro", "Esturjão")),
    BundleGroup("Aquário • Peixes do oceano", listOf("Sardinha", "Atum", "Cioba", "Tilápia"))
)

@Composable
fun StardewApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("stardew_companion", Context.MODE_PRIVATE) }
    var page by remember { mutableStateOf("Início") }
    var search by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("Tudo") }
    var season by remember { mutableStateOf("Primavera") }
    var checked by remember { mutableStateOf(prefs.getStringSet("checked", emptySet())?.toSet() ?: emptySet()) }
    var favorites by remember { mutableStateOf(prefs.getStringSet("favorites", emptySet())?.toSet() ?: emptySet()) }
    var planned by remember { mutableStateOf(prefs.getStringSet("planned", emptySet())?.toSet() ?: emptySet()) }

    fun persist(key: String, values: Set<String>) {
        prefs.edit().putStringSet(key, values.toSet()).apply()
    }
    fun openWiki(slug: String) {
        val url = "https://pt.stardewvalleywiki.com/" + slug.replace(" ", "_")
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }

    MaterialTheme(colorScheme = lightColorScheme(
        primary = Forest, onPrimary = Color.White, secondary = Gold,
        background = Cream, surface = Paper, onSurface = Ink
    )) {
        Scaffold(
            containerColor = Cream,
            bottomBar = { GameBottomBar(page) { page = it } }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                GameHeader(page)
                when (page) {
                    "Início" -> HomeScreen(
                        checked.size, planned.size, favorites.size,
                        onGo = { page = it }
                    )
                    "Wiki" -> WikiScreen(search, { search = it }, filter, { filter = it },
                        favorites, { val updated = favorites + it; favorites = updated; persist("favorites", updated) },
                        ::openWiki)
                    "Pacotes" -> BundlesScreen(checked, { item, value ->
                        checked = if (value) checked + item else checked - item
                        persist("checked", checked)
                    }, ::openWiki)
                    "Cultivos" -> CropsScreen(season, { season = it }, planned, { item ->
                        planned = if (planned.contains(item)) planned - item else planned + item
                        persist("planned", planned)
                    })
                    "Salvos" -> FavoritesScreen(favorites, { item ->
                        val updated = favorites - item; favorites = updated; persist("favorites", updated)
                    }, ::openWiki)
                }
            }
        }
    }
}

@Composable
fun GameHeader(page: String) {
    Column(Modifier.fillMaxWidth().background(Forest).padding(horizontal = 18.dp, vertical = 15.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("🌱", fontSize = 30.sp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("STARDEW COMPANION", color = Color.White, fontWeight = FontWeight.Black, fontSize = 18.sp, letterSpacing = 1.sp)
                Text("Caderno do Vale • ${page}", color = Color(0xFFE5E9C9), fontSize = 12.sp)
            }
            Text("✦", color = Gold, fontSize = 25.sp)
        }
    }
}

@Composable
fun GamePanel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.fillMaxWidth()
            .background(Paper, RoundedCornerShape(9.dp))
            .border(2.dp, Brown.copy(alpha = .65f), RoundedCornerShape(9.dp))
            .padding(13.dp),
        content = content
    )
}

@Composable
fun PixelButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(modifier.background(Forest, RoundedCornerShape(6.dp)).border(2.dp, Color(0xFF203D28), RoundedCornerShape(6.dp))
        .clickable { onClick() }.padding(horizontal = 12.dp, vertical = 10.dp), contentAlignment = Alignment.Center) {
        Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}

@Composable
fun HomeScreen(checked: Int, planned: Int, favorites: Int, onGo: (String) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        GamePanel {
            Text("BEM-VINDO AO VALE!", color = Forest, fontWeight = FontWeight.Black, fontSize = 17.sp)
            Text("Seu guia de bolso para organizar a fazenda, descobrir itens e completar coleções.", color = Brown, fontSize = 13.sp)
            Spacer(Modifier.height(9.dp))
            Text("☀  Um novo dia, novas possibilidades.", color = Leaf, fontWeight = FontWeight.Bold)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatTile("📦", checked.toString(), "Itens marcados", Modifier.weight(1f))
            StatTile("🌾", planned.toString(), "Planos de cultivo", Modifier.weight(1f))
            StatTile("⭐", favorites.toString(), "Favoritos", Modifier.weight(1f))
        }
        Text("ATALHOS", color = Forest, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
        listOf("Wiki" to "📖 Consultar a Wiki", "Pacotes" to "📦 Centro Comunitário", "Cultivos" to "🌱 Planejar plantações", "Salvos" to "⭐ Meus favoritos").forEach { (dest, label) ->
            GamePanel {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(label, color = Ink, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    PixelButton("ABRIR") { onGo(dest) }
                }
            }
        }
        Text("Os dados marcados ficam salvos neste aparelho.", color = Muted, fontSize = 11.sp)
    }
}
@Composable
fun StatTile(icon: String, value: String, label: String, modifier: Modifier = Modifier) {
    GamePanel(modifier) {
        Text(icon, fontSize = 19.sp)
        Text(value, color = Forest, fontWeight = FontWeight.Black, fontSize = 22.sp)
        Text(label, color = Muted, fontSize = 10.sp)
    }
}

@Composable
fun WikiScreen(search: String, onSearch: (String) -> Unit, filter: String, onFilter: (String) -> Unit,
               favorites: Set<String>, addFavorite: (String) -> Unit, openWiki: (String) -> Unit) {
    val filtered = catalog.filter { (search.isBlank() || it.name.contains(search, true) || it.type.contains(search, true)) &&
        (filter == "Tudo" || it.type == filter) }
    Column(Modifier.fillMaxSize().padding(14.dp)) {
        GamePanel {
            Text("BIBLIOTECA DO VALE", color = Forest, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = search, onValueChange = onSearch, modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Buscar item, peixe, morador...") }, singleLine = true)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Tudo", "Cultivo", "Morador", "Peixe", "Local", "Guia", "Coleção", "Equipamento", "Semente").forEach { f ->
                    FilterChip(selected = filter == f, onClick = { onFilter(f) }, label = { Text(f) })
                }
            }
            Text("Os nomes do catálogo seguem a nomenclatura em português da Wiki. Abra o artigo para consultar os dados completos.", color = Muted, fontSize = 11.sp)
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            items(filtered) { entry ->
                GamePanel {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(entry.name, fontWeight = FontWeight.Bold, color = Ink)
                            Text(entry.type.uppercase(), color = Leaf, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text(entry.description, color = Muted, fontSize = 11.sp)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            TextButton(onClick = { addFavorite(entry.name) }) {
                                Text(if (favorites.contains(entry.name)) "★" else "☆", fontSize = 22.sp, color = Gold)
                            }
                            TextButton(onClick = { openWiki(entry.wikiSlug) }) { Text("WIKI ↗", fontSize = 10.sp) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BundlesScreen(checked: Set<String>, onCheck: (String, Boolean) -> Unit, openWiki: (String) -> Unit) {
    val all = bundleGroups.flatMap { it.items }
    val done = all.count { checked.contains(it) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        GamePanel {
            Text("CENTRO COMUNITÁRIO", color = Forest, fontWeight = FontWeight.Black, fontSize = 17.sp)
            Text("$done de ${all.size} itens marcados", color = Brown, fontSize = 12.sp)
            LinearProgressIndicator(progress = { if (all.isEmpty()) 0f else done.toFloat() / all.size }, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), color = Leaf)
            Text("Checklist inicial. A lista será expandida para incluir todos os conjuntos e requisitos da Wiki.", color = Muted, fontSize = 11.sp)
            PixelButton("CONSULTAR WIKI") { openWiki("Conjuntos") }
        }
        bundleGroups.forEach { group ->
            var expanded by remember { mutableStateOf(false) }
            GamePanel {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(group.name, color = Forest, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text("${group.items.count { checked.contains(it) }}/${group.items.size}", color = Muted, fontSize = 11.sp)
                    TextButton(onClick = { expanded = !expanded }) { Text(if (expanded) "−" else "+") }
                }
                if (expanded) group.items.forEach { item ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = checked.contains(item), onCheckedChange = { onCheck(item, it) })
                        Text(item, color = Ink, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun CropsScreen(season: String, onSeason: (String) -> Unit, planned: Set<String>, toggle: (String) -> Unit) {
    val crops = mapOf(
        "Primavera" to listOf("Pastinaca", "Vagem", "Couve-flor", "Batata", "Morango", "Couve", "Ruibarbo"),
        "Verão" to listOf("Melão", "Tomate", "Mirtilo", "Pimenta quente", "Milho", "Lúpulo", "Carambola"),
        "Outono" to listOf("Abóbora", "Oxicoco", "Berinjela", "Inhame", "Uva", "Amaranto", "Alcachofra"),
        "Inverno" to listOf("Nenhum cultivo sazonal ao ar livre")
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        GamePanel {
            Text("PLANEJADOR DE LAVOURAS", color = Forest, fontWeight = FontWeight.Black)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                crops.keys.forEach { s -> FilterChip(selected = season == s, onClick = { onSeason(s) }, label = { Text(s) }) }
            }
            Text("Selecione os cultivos que pretende plantar nesta estação.", color = Muted, fontSize = 11.sp)
        }
        crops[season].orEmpty().forEach { crop ->
            GamePanel {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("🌱", fontSize = 19.sp)
                    Spacer(Modifier.width(8.dp))
                    Text(crop, modifier = Modifier.weight(1f), color = Ink, fontWeight = FontWeight.Bold)
                    Checkbox(checked = planned.contains("$season|$crop"), onCheckedChange = { toggle("$season|$crop") })
                }
            }
        }
    }
}

@Composable
fun FavoritesScreen(favorites: Set<String>, remove: (String) -> Unit, openWiki: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(14.dp)) {
        GamePanel {
            Text("SEU BAÚ DE FAVORITOS", color = Forest, fontWeight = FontWeight.Black)
            Text("Itens que você guardou para consultar depois.", color = Muted, fontSize = 11.sp)
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(favorites.toList().sorted()) { item ->
                GamePanel {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("⭐ $item", modifier = Modifier.weight(1f), color = Ink, fontWeight = FontWeight.Bold)
                        TextButton(onClick = { openWiki(item.replace(" ", "_")) }) { Text("WIKI") }
                        TextButton(onClick = { remove(item) }) { Text("✕", color = Color(0xFF9A4538)) }
                    }
                }
            }
        }
    }
}

@Composable
fun GameBottomBar(current: String, onSelect: (String) -> Unit) {
    val items = listOf("Início" to "⌂", "Wiki" to "⌕", "Pacotes" to "▦", "Cultivos" to "♧", "Salvos" to "☆")
    Row(Modifier.fillMaxWidth().background(Color(0xFF294631)).navigationBarsPadding().padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceEvenly) {
        items.forEach { (name, icon) ->
            Column(Modifier.weight(1f).clickable { onSelect(name) }.padding(vertical = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(icon, color = if (current == name) Gold else Color(0xFFE6E0C9), fontSize = 22.sp)
                Text(name, color = if (current == name) Color.White else Color(0xFFD0D7C5), fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
